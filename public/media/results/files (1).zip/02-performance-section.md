# Claude Code prompt — Performance section

Paste everything below the line into Claude Code from the root of the Taizan Capital site repo.

---

Build the **Performance / track record** section for the Taizan Capital site.

## Context

The site is a Japanese-inspired institutional theme — cinematic Fuji, forest and river sections with mist transitions and scroll-reactive motion. This section sits between the investment strategy section and the end of the page. It must feel like a fund tearsheet, not a fintech dashboard: precise, restrained, data-forward. Read the existing components first and match the established type scale, spacing rhythm, motion timing and color tokens rather than introducing new ones. If tokens don't exist yet, create them in the shared theme file and refactor this section to consume them.

## What the section shows

A single growth-of-capital chart comparing an actual track record against the S&P 500, plus a compact statistics strip and a methodology note.

The comparison is a **counterfactual**: identical cash flows on identical dates, invested in IVV.AX (ASX-listed S&P 500 tracker, AUD, distributions reinvested) instead of the actual holdings. This is stated plainly, not buried.

## Data

Hardcode this into a typed data module (`src/data/performance.ts` or the equivalent for this project's structure) — no API calls, no CSV parsing. Every figure is AUD.

```ts
export const AS_AT = "2026-06-30";
export const INCEPTION = "2023-02-01";

// Portfolio marked at 30 June valuations only. There are no intra-year marks —
// do NOT interpolate additional points or synthesise a daily series.
export const series = [
  { date: "2023-02-01", portfolio: 1120,     benchmark: 1120,     capital: 1120     },
  { date: "2023-06-30", portfolio: 1109.00,  benchmark: 1194.00,  capital: 1082.50  },
  { date: "2024-06-30", portfolio: 3855.27,  benchmark: 4273.00,  capital: 3501.41  },
  { date: "2025-06-30", portfolio: 22854.27, benchmark: 23954.00, capital: 20929.00 },
  { date: "2026-06-30", portfolio: 35512.35, benchmark: 38132.04, capital: 30558.92 },
];

export const stats = [
  { label: "XIRR",           portfolio: "11.63%", benchmark: "17.36%", note: "p.a., money-weighted" },
  { label: "Annualised TWR", portfolio: "11.48%", benchmark: "19.90%", note: "time-weighted" },
  { label: "Cumulative TWR", portfolio: "44.82%", benchmark: "85.62%", note: "since inception" },
];

export const annual = [
  { period: "FY23 (5 months)", portfolio: 2.43,  benchmark: 10.12 },
  { period: "FY24",            portfolio: 13.75, benchmark: 26.48 },
  { period: "FY25",            portfolio: 11.46, benchmark: 15.27 },
  { period: "FY26",            portfolio: 11.51, benchmark: 15.61 },
];

export const terminal = { portfolio: 35512.35, benchmark: 38132.04, gap: -2619.69, gapPct: -6.9 };
```

## Chart requirements

- Line chart, five points per series, plotted on a categorical x-axis (`Feb 23`, `Jun 23`, `Jun 24`, `Jun 25`, `Jun 26`) — the gaps between marks are unequal in time and the categorical axis makes that honest rather than implying a smooth path.
- Three series: **Portfolio** (gold, heaviest stroke), **S&P 500 counterfactual** (a cool blue that reads as secondary against the gold — do not use a second warm tone), **Net capital invested** (muted slate, dashed, thin).
- Fill the band between portfolio and benchmark at low opacity in the benchmark colour. The band is the point of the chart — it is the shortfall.
- Terminal values labelled in the right margin with the gap called out beneath: `−$2,620 (−6.9%)`.
- Y-axis in `$0k … $40k`, horizontal gridlines only, no vertical gridlines, no chart border.
- Straight segments between marks. No curve smoothing — smoothing here would invent a path that was never observed.

## Motion

One orchestrated reveal on scroll-into-view, matching the site's existing easing and duration:

1. Axis and gridlines fade in.
2. Both lines draw left to right via `stroke-dasharray` / `stroke-dashoffset`, benchmark first, portfolio ~150ms behind it.
3. The shortfall band fades in once both lines have landed.
4. Statistics strip counts up to its values.

Respect `prefers-reduced-motion: reduce` — render the final state immediately with no draw or count-up.

## Implementation notes

- Prefer a hand-rolled inline SVG over a charting library. Five points across three series does not justify the bundle weight, and the draw-on animation is far easier to control on raw paths.
- Responsive: below ~640px drop the net-capital line, move terminal labels above their endpoints instead of into the right margin, and stack the statistics strip two-up.
- Accessibility: give the SVG `role="img"` and an `aria-label` stating the headline comparison; render the `annual` array as a visually-hidden `<table>` so the underlying figures are reachable by screen readers and by anyone who wants the numbers rather than the picture.
- No `localStorage`, no runtime data fetching.

## Methodology note

Render this beneath the chart in the site's small-print style. It is not optional — the numbers are indefensible without it.

> Portfolio marked at 30 June valuations; no intra-year marks are observed. Benchmark is IVV.AX with distributions reinvested, receiving the identical cash flows on the identical dates. XIRR is money-weighted; TWR is chain-linked Modified Dietz. Returns are net of brokerage and before tax; franking credits are excluded. IVV prices before July 2024 are reconstructed from financial-year closes and reported calendar-year returns. Past performance is not a reliable indicator of future performance.

## Definition of done

Section renders at 375px, 768px and 1440px; reduced-motion path verified; no console errors; figures on screen tie exactly to `performance.ts`; the word "counterfactual" or an equivalent plain-English framing appears in the visible copy so no reader can mistake the blue line for a second real portfolio.
