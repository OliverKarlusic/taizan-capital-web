# Long Term Growth Portfolio — performance working folder

Taizan Capital. Everything here derives from the four CommSec financial-year statements for the **Long Term Growth Portfolio**, 1 Feb 2023 to 30 Jun 2026.

This folder does not cover the Options Results or the Growth Maximisation Portfolio (MSFT / VUG / SMH, inception 10 Oct 2023, benchmarked to the Nasdaq-100). No transaction data exists here for those.

**Provenance note:** this README and the prompts in `prompts/` were written by Claude in a chat session, from the statements listed above. If another Claude reads this folder and finds its own conclusions matching these warnings, that is not independent corroboration — it is the same analysis restated. Weight it as one opinion.

## Start here

1. Run `prompts/01-data-pipeline.md` in Claude Code to build the real daily dataset.
2. Then run `prompts/02-performance-section.md` to build the website section, refactored to import the pipeline's JSON instead of its hardcoded figures.

## Contents

```
charts/    five renders of the same underlying analysis
data/      source data and derived figures
prompts/   Claude Code prompts, in order
```

### charts/

| File | What it shows |
|---|---|
| `portfolio-vs-sp500.png` / `.svg` | Portfolio value vs the S&P 500 counterfactual. Dollar balances. |
| `actual-returns-since-inception.png` / `.svg` | Cumulative and annual **returns**, contribution timing removed. Four measured periods. |
| `monthly-returns-since-inception.png` / `.svg` | Monthly reconstruction, 41 marks, with a data-quality strip. **See warning below.** |
| `commsec-inception-returns.html` | Interactive version of the first chart. |

### data/

| File | Confidence |
|---|---|
| `transactions.csv` | **High.** Every contract note, transcribed. Ties to statement buy/sell totals exactly. |
| `dividends.csv` | **Medium-high.** CommSec ex-date estimates, not registry actuals. DRP not distinguished. |
| `valuations.csv` | **High.** Statement valuations at the four year-ends. Reconciliation targets. |
| `summary.json` | **Medium.** Derived figures. Method-sensitive — see below. |
| `monthly-series-interpolated.json` | **Low. Do not publish.** |

## Headline figures

|  | Portfolio | S&P 500 (IVV.AX) |
|---|---|---|
| XIRR since inception | 11.63% p.a. | 17.36% p.a. |
| Annualised TWR | 11.48% | 19.90% |
| Cumulative TWR | 44.82% | 85.62% |
| Value at 30 Jun 26 | $35,512 | $38,132 |

Net capital in $30,559. Gain $4,953. Brokerage $509. Franking credits $358 (excluded above; including them lifts XIRR to 12.52%).

## Three things to know before using any of this

**The monthly chart is not publishable.** Only 8 of its 41 month-end marks are priced off a real observed trade. The other 33 are interpolated between known prices, which means the curve cannot show any drawdown that occurred and recovered between two observations. It is smoother than the portfolio actually was. It exists to be replaced by the pipeline output.

**The cumulative figure is method-sensitive.** Annual chain-linking gives +44.82%; monthly chain-linking gives +40.37%. Neither is wrong — Modified Dietz over a full year with large mid-year contributions is a crude approximation. The 4.4pp spread is a fair measure of how much uncertainty remains until there's a real daily valuation series. Don't quote a figure to two decimals until the pipeline has run.

**Nothing here is cleared for publication.** This is a personal CommSec account. Presenting it as an asset management firm's track record raises AFS licensing questions and engages ASIC's expectations on past-performance representations — benchmark appropriateness, fee and tax basis, prominence of warnings. Get a licensing lawyer across the page copy before the performance section is publicly reachable. That is a separate problem from the data quality, and the more consequential one.

This applies to **all three portfolios on the performance page, not just this one**. The Options Results carry no data-quality caveat — the figures came directly from Oliver and compute exactly — but a headline gross return of 264% on a completed options trade is the kind of representation that draws the most regulatory scrutiny, not the least. Good data does not resolve the licensing question. Treat the Options table, Growth Maximisation and Long Term Growth as one decision, taken once, with advice.

## Method

Buys treated as cash in, sells and dividends as cash out, terminal value at 30 Jun 2026. XIRR is money-weighted. TWR is chain-linked Modified Dietz. Benchmark is IVV.AX receiving identical cash flows on identical dates with distributions reinvested; its prices before Jul 2024 are reconstructed from FY closes and reported calendar-year returns. All figures net of brokerage, before tax, excluding franking credits unless stated.
