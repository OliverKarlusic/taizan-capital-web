# Claude Code prompt — build the real performance dataset

Run this from the repo root. It needs network access and will install Python packages.

---

Build a reproducible pipeline that computes my actual portfolio performance from daily market data and emits a JSON file the website consumes.

## Inputs already in this folder

- `data/transactions.csv` — every buy and sell, 1 Feb 2023 to 30 Jun 2026: `date, ticker, units, total_value_aud, side`. Units are signed (negative = sell). `total_value_aud` is inclusive of brokerage and GST.
- `data/dividends.csv` — every dividend and distribution received, by pay date.
- `data/valuations.csv` — CommSec portfolio valuations at the four financial-year ends. **These are the reconciliation targets. Treat them as ground truth.**
- `data/summary.json` — the figures previously derived from annual statements only. Useful as a sanity reference; expect the daily rebuild to differ slightly and prefer the daily result.

## What you need to fetch

Daily OHLC for these ASX tickers from 1 Feb 2023 to today — all need the `.AX` suffix:

`FMG, VAS, YAL, ABG, BOND, IVV, NDQ, VGN, CSL, NXT`

Plus `IVV.AX` again as the benchmark, and its distribution history.

Use `yfinance` or an equivalent. Cache raw downloads to `data/prices/{TICKER}.csv` so reruns don't refetch. Some tickers may be delisted or renamed (VGN — Virgin Australia; ABG — Abacus; BOND — SPDR bond ETF) — if a symbol fails, try alternates and report which resolved.

**Critical: use unadjusted Close, not Adj Close.** Dividends are already separate cash flows in `dividends.csv`. Adjusted prices would double-count them and break reconciliation.

## Two assertions that must pass before anything is written

**1. Prices are genuinely unadjusted.** For every row in `transactions.csv`, the implied unit price (`total_value_aud / units`, net of roughly $5–20 brokerage) must fall within that day's `Low`–`High` range for that ticker, allowing 1% tolerance. If trade prices systematically sit *above* the daily high, the series is back-adjusted — stop and report rather than proceeding. This exact failure has already been observed on one data source.

**2. Valuations reconcile.** Rebuild unit holdings from `transactions.csv` and mark to market. Portfolio value at each date in `valuations.csv` must match to within $5:

```
2023-06-30 →  1,109.00
2024-06-30 →  3,855.27
2025-06-30 → 22,854.27
2026-06-30 → 35,512.35
```

Fail loudly with a per-ticker breakdown of the discrepancy. Do not fall back to interpolation, do not adjust figures to force a match, do not proceed to the chart data.

## What to compute

- Daily portfolio value from the unit ledger.
- Daily time-weighted return, chain-linked, treating buys as inflows and sells and dividends as outflows on their actual dates. Report cumulative and annualised.
- XIRR since inception, money-weighted.
- Max drawdown with peak and trough dates; annualised volatility from daily returns; best and worst month.
- The same set for the benchmark counterfactual: identical cash flows on identical dates into IVV.AX with distributions reinvested at the ex-date price.
- Tracking difference: portfolio TWR minus benchmark TWR, annualised.

## Output

Write `src/data/performance.json`:

```jsonc
{
  "meta": { "inception": "...", "asOf": "...", "generatedAt": "...",
            "priceSource": "...", "method": "daily chain-linked TWR" },
  "series": [ { "date": "YYYY-MM-DD", "portfolioIndex": 100.0, "benchmarkIndex": 100.0 } ],
  "stats": { "twrCum": 0, "twrAnn": 0, "xirr": 0, "maxDrawdown": 0,
             "maxDrawdownFrom": "...", "maxDrawdownTo": "...",
             "volAnn": 0, "benchmark": { /* same shape */ } },
  "annual": [ { "period": "FY24", "portfolio": 0, "benchmark": 0 } ]
}
```

`series` carries indexed returns (base 100), **not dollar balances** — this file may end up in a public repo and the return series is what the site needs. Write dollar-denominated output to `data/private/` and add that path to `.gitignore`.

Print the reconciliation table and the stats block to stdout so I can eyeball them before committing.

## Constraints

- Python, standard scientific stack. One entry point: `python scripts/build_performance.py`.
- Idempotent — safe to rerun monthly.
- Any credential goes in `.env`, read from the environment, never hardcoded. `.env` in `.gitignore`.
- No silent fallbacks anywhere. If data is missing for a date, say so; do not fill it in.

## When it passes

Report the reconciliation table, the stats, and how the daily figures differ from `data/summary.json`. Then stop — I'll review before wiring it into the performance section (see `prompts/02-performance-section.md` (Taizan Capital), which currently hardcodes the annual figures and should be refactored to import this JSON).
